package com.casestudy.model;


import org.springframework.data.annotation.Id;

import jakarta.persistence.Column;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name=" ")
public class AuthenticationResponse {
	@Id
	@Column(name="Jwt")
	private String jwt;
	
	@Column(name="Success")
	private String success;
	
	
	
	
	

}
