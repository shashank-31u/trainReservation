package com.casestudy.services;

import java.util.Date;

public class JwtUtil {
	
	 private String SECRET_KEY = "secret";
	
//	 
//	 private String createToken(Map<String, Object> claims, String subject) {
//
//	        return Jwts.builder().setClaims(claims).setSubject(subject).setIssuedAt(new Date(System.currentTimeMillis()))
//	                .setExpiration(new Date(System.currentTimeMillis() + 1000 * 60 * 60 * 10))
//	                .signWith(SignatureAlgorithm.HS256, SECRET_KEY).compact();
//	    }	    


}
