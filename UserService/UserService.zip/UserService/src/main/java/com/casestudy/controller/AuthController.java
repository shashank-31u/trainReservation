package com.casestudy.controller;


public class AuthController {
	
	
}
