package com.casestudy.configuration;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfiguration;
@Configuration
@EnableWebSecurity


public class SecurityConfiguration  extends WebSecurityConfiguration{
//	@Autowired
//	private UserService userService;
//	
//	
	
	
	
	

}
