package com.casestudy.model;

import org.springframework.data.annotation.Id;


import javax.persistence.Column;
import javax.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name="Authreq")
public class AuthenticationRequest {
	@Id
	@Column(name="Username")
	private String username;
	
	@Column(name="Password")
	private String password;

}
